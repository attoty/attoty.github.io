# Credits

Based on the hard work of [@dgym](https://github.com/dgym) on
[cpython-emscripten](https://github.com/dgym/cpython-emscripten).
