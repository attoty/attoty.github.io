int
do_the_thing(int a, int b);

int
dep_do_the_thing(int a, int b);

int
dep_dep_do_the_thing(int a);
