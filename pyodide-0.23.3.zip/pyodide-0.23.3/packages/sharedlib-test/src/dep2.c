#include "include/sharedlibtest.h"

int
dep_dep_do_the_thing(int a)
{
  return a;
}
