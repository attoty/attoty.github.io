---
name: Package request
about: Request a new Python package or a version update
title: ""
labels: new package request
assignees: ""
---

<!-- Important Note: You can install pure python package wheels through micropip.install(...) -->

## 🐍 Package Request

- Package Name and Version <!-- (e.g. pandas / latest) -->:
- Package URL <!--  (e.g. github link, PyPI link) -->:
- Package Dependencies that needs to be resolved first:
