# API Reference

```{eval-rst}
.. toctree::
   :maxdepth: 2

   api/js-api.md
   api/python-api.md
   Micropip API <https://micropip.pyodide.org/en/stable/project/api.html>
   api/pyodide-cli.md
```
