# pyodide.http

```{eval-rst}
.. currentmodule:: pyodide.http

.. automodule:: pyodide.http
   :members:
   :autosummary:
   :autosummary-no-nesting:
```
