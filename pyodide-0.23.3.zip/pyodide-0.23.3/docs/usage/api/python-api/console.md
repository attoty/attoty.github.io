# pyodide.console

```{eval-rst}
.. currentmodule:: pyodide.console

.. automodule:: pyodide.console
   :members:
   :autosummary:
   :autosummary-no-nesting:
```
