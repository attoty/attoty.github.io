# pyodide.ffi

```{eval-rst}
.. currentmodule:: pyodide.ffi

.. automodule:: pyodide.ffi
   :members:
   :autosummary:
   :autosummary-no-nesting:
   :show-inheritance:

.. automodule:: pyodide.ffi.wrappers
   :members:
   :autosummary:
   :autosummary-no-nesting:
```
